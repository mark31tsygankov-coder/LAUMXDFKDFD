# OMNIRO ONLINE Launcher (source project)

Windows launcher source for OMNIRO ONLINE / CRMP. It launches a local `samp.exe` with a configured server address and shows a built-in news feed.

## Requirements
- Windows 10/11
- .NET 8 SDK to build from source
- Your legally obtained CRMP client files, including `samp.exe`

## Build
1. Install the .NET 8 SDK: https://dotnet.microsoft.com/download/dotnet/8.0
2. Open `OMNIRO.ONLINE.Launcher.sln` in Visual Studio 2022, or open a terminal in this folder.
3. Run:
   ```powershell
   dotnet publish .\OMNIRO.ONLINE.Launcher\OMNIRO.ONLINE.Launcher.csproj -c Release -r win-x64 --self-contained true /p:PublishSingleFile=true
   ```
4. The published EXE will be in:
   `OMNIRO.ONLINE.Launcher\bin\Release\net8.0-windows\win-x64\publish\`

This project archive contains source code, not a prebuilt EXE. Build it on Windows with the .NET SDK.

## Configure
- Default server: `82.47.171.239:7795`
- Default client path: `samp.exe` in the launcher folder, or choose the executable using "Путь к клиенту".
- Community URL can be changed in `MainWindow.xaml.cs` (`CommunityUrl`).
- News examples are local sample posts and can be edited in `MainWindow.xaml.cs`.

## Notes
- Different SA-MP/CRMP clients may accept different launch arguments. The launcher first tries the common `samp.exe IP:PORT` form. If your client needs a different form, edit `BuildStartInfo()` in `MainWindow.xaml.cs`.
- The launcher does not include the game client or copyrighted game assets.
