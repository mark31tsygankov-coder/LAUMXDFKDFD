using Microsoft.Win32;
using System.Diagnostics;
using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Media;

namespace OmniroOnlineLauncher;

public partial class MainWindow : Window
{
    private const string CommunityUrl = "https://t.me/";
    private readonly string settingsPath = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "OMNIROONLINE", "launcher-settings.json");

    private LauncherSettings settings = new();

    public MainWindow()
    {
        InitializeComponent();
        LoadSettings();
        NewsList.ItemsSource = new[]
        {
            new NewsItem("НОВОСТИ • 27.10.2026", "OMNIRO ONLINE открывает двери",
                "Добро пожаловать! Следите за обновлениями проекта и готовьтесь к игре."),
            new NewsItem("ОБЪЯВЛЕНИЕ • 26.10.2026", "Проверка клиента",
                "Перед запуском убедитесь, что выбран правильный клиент CRMP 8.4."),
            new NewsItem("СООБЩЕСТВО • 25.10.2026", "Будь частью истории",
                "Присоединяйтесь к сообществу, чтобы следить за новостями проекта.")
        };
        UpdateClientStatus();
    }

    private void LoadSettings()
    {
        try
        {
            if (File.Exists(settingsPath))
                settings = JsonSerializer.Deserialize<LauncherSettings>(File.ReadAllText(settingsPath)) ?? new();
        }
        catch { settings = new(); }

        IpBox.Text = string.IsNullOrWhiteSpace(settings.Ip) ? "82.47.171.239" : settings.Ip;
        PortBox.Text = string.IsNullOrWhiteSpace(settings.Port) ? "7795" : settings.Port;
    }

    private void SaveSettings()
    {
        if (string.IsNullOrWhiteSpace(IpBox.Text))
        {
            MessageBox.Show("Укажи IP-адрес сервера.", "OMNIRO ONLINE", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        if (!ushort.TryParse(PortBox.Text, out _))
        {
            MessageBox.Show("Порт должен быть числом от 1 до 65535.", "OMNIRO ONLINE", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        settings.Ip = IpBox.Text.Trim();
        settings.Port = PortBox.Text.Trim();
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(settingsPath)!);
            File.WriteAllText(settingsPath, JsonSerializer.Serialize(settings, new JsonSerializerOptions { WriteIndented = true }));
            UpdateClientStatus();
            MessageBox.Show("Настройки сохранены.", "OMNIRO ONLINE", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Не удалось сохранить настройки: {ex.Message}", "OMNIRO ONLINE", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void SaveSettings_Click(object sender, RoutedEventArgs e) => SaveSettings();

    private void ChooseClient_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog
        {
            Title = "Выбери исполняемый файл клиента CRMP",
            Filter = "Клиент игры (samp.exe)|samp.exe|Исполняемые файлы (*.exe)|*.exe",
            CheckFileExists = true
        };
        if (dialog.ShowDialog() == true)
        {
            settings.ClientPath = dialog.FileName;
            SaveSettingsQuietly();
            UpdateClientStatus();
        }
    }

    private void PlayButton_Click(object sender, RoutedEventArgs e)
    {
        SaveSettingsQuietly();
        var clientPath = settings.ClientPath;
        if (string.IsNullOrWhiteSpace(clientPath) || !File.Exists(clientPath))
        {
            var localClient = Path.Combine(AppContext.BaseDirectory, "samp.exe");
            if (File.Exists(localClient))
                clientPath = localClient;
            else
            {
                MessageBox.Show("Сначала выбери samp.exe кнопкой «ВЫБРАТЬ ПУТЬ К КЛИЕНТУ». Сам клиент в архив не входит.",
                    "Клиент не найден", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
        }

        try
        {
            var startInfo = BuildStartInfo(clientPath, IpBox.Text.Trim(), PortBox.Text.Trim());
            Process.Start(startInfo);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Не удалось запустить клиент: {ex.Message}", "Ошибка запуска", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private static ProcessStartInfo BuildStartInfo(string clientPath, string ip, string port)
    {
        // Common SA-MP launch convention. Some CRMP clients require different arguments.
        return new ProcessStartInfo
        {
            FileName = clientPath,
            Arguments = $"{ip}:{port}",
            WorkingDirectory = Path.GetDirectoryName(clientPath) ?? AppContext.BaseDirectory,
            UseShellExecute = true
        };
    }

    private void Community_Click(object sender, RoutedEventArgs e)
    {
        try { Process.Start(new ProcessStartInfo { FileName = CommunityUrl, UseShellExecute = true }); }
        catch (Exception ex) { MessageBox.Show($"Не удалось открыть ссылку: {ex.Message}"); }
    }

    private void SaveSettingsQuietly()
    {
        settings.Ip = IpBox.Text.Trim();
        settings.Port = PortBox.Text.Trim();
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(settingsPath)!);
            File.WriteAllText(settingsPath, JsonSerializer.Serialize(settings, new JsonSerializerOptions { WriteIndented = true }));
        }
        catch { }
    }

    private void UpdateClientStatus()
    {
        var path = settings.ClientPath;
        if (string.IsNullOrWhiteSpace(path) || !File.Exists(path))
        {
            var local = Path.Combine(AppContext.BaseDirectory, "samp.exe");
            path = File.Exists(local) ? local : "";
        }

        StatusText.Text = string.IsNullOrWhiteSpace(path)
            ? "Клиент не выбран — укажи путь к samp.exe"
            : $"Клиент готов: {Path.GetFileName(path)}";
        StatusText.Foreground = string.IsNullOrWhiteSpace(path)
            ? new SolidColorBrush(Color.FromRgb(229, 57, 53))
            : new SolidColorBrush(Color.FromRgb(80, 200, 120));
    }

    private sealed class LauncherSettings
    {
        public string Ip { get; set; } = "82.47.171.239";
        public string Port { get; set; } = "7795";
        public string ClientPath { get; set; } = "";
    }

    private sealed record NewsItem(string Date, string Title, string Body);
}
