using System.Windows;

namespace OmniroOnlineLauncher;

public partial class App : Application
{
}
